<footer id="main-footer" class="bg-light text-dark text-capitalize font-weight-bold mt-5 p-2">
   <div class="container">
      <div class="row">
         <div class="col">
            <p class="lead text-center">
               Copyright &copy;
               <span id="year"></span>
               ZimPlats
            </p>
         </div>
      </div>
   </div>
</footer>


</body>

</html>