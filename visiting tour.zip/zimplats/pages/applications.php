<?php include('page_header.php')
?>

<?php include('navbar.php'); ?>



<section id="actions" class="py-4 bg-light">
   <h1 class="text-center">
      <a href="" class="btn btn-primary" data-toggle="modal" data-target="#addPostModal">
         Book Specific Slot
      </a>
   </h1>
</section>



<?php

if (isset($_POST['apply'])) {
   $full_names = $_POST['full_names'];
   $national_id = $_POST['national_id'];
   $phone = $_POST['phone'];
   $occupation = $_POST['occupation'];
   $nature_of_visit = $_POST['nature_of_visit'];
   $visiting_date = $_POST['visiting_date'];

   $status = "pending";


   $sql = "INSERT INTO applications (full_names, national_id, phone, occupation, nature_of_visit, visiting_date, status)
      VALUES ('{$full_names}', '{$national_id}', '{$phone}','{$occupation}','{$nature_of_visit}','{$visiting_date}','{$status}')";

   if ($conn->query($sql) === TRUE) {
      echo "<p class='alert alert-success text-dark text-center p-3'>Application was created successfully, Check your response after few minutes</p>";
   } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
   }
}


?>


<div class="modal fade" id="addPostModal">
   <div class="modal-dialog modal-lg">
      <div class="modal-content">
         <div class="modal-header bg-primary text-white">
            <h5 class="modal-title">Apply Specific Slot</h5>
            <button class="close" data-dismiss="modal">
               <span>&times;</span>
            </button>
         </div>
         <div class="modal-body">
            <form action="" method="POST">
               <div class="form-group">
                  <label for="title">Fullnames</label>
                  <input type="text" name="full_names" minlength="5" class="form-control" required>
               </div>
               <div class="form-group">
                  <label for="title">National ID</label>
                  <input type="text" name="national_id" minlength="5" class="form-control" required>
               </div>

               <div class="form-group">
                  <label for="title">Phone Number</label>
                  <input type="text" name="phone" minlength="6" class="form-control" required>
               </div>

               <div class="form-group">
                  <label for="title">Occupation</label>
                  <input type="text" name="occupation" minlength="5" class="form-control" required>
               </div>

               <div class="form-group">
                  <label for="title">Nature of Visit</label>
                  <textarea name="nature_of_visit" minlength="5" class="form-control" id="" cols="10" rows="3" required></textarea>
               </div>

               <div class="form-group">
                  <label for="title">Visitng Date you want</label>
                  <input type="date" name="visiting_date" class="form-control" required>
               </div>

         </div>
         <div class="modal-footer">
            <button type="submit" name="apply" class="btn btn-primary">Submit</button>
         </div>

         </form>
      </div>
   </div>
</div>


<!-- Available slots -->
<section class=" text-white">
   <div class="container">
      <h4 class="text-info text-center text-capitalize font-weight-bold">Hurry book for Available slot</h4>
      <div class="row text-center">
         <?php
         $ss = true;
         $sql = "SELECT * FROM slots WHERE status = $ss";
         $result = $conn->query($sql);

         if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
               $slot_id = $row["slot_id"];
               $assistance = $row["assistance"];
               $activities = $row["activities"];
               $duration = $row["duration"];
               $visiting_date = $row["visiting_date"];
         ?>
               <div class="col-md-3">
                  <div class="card mt-2">
                     <div class="card-header text-dark text-capitalize font-weight-bolder">Slot details</div>
                     <div class="card-body">
                        <p class="p-2 mb-3 bg-dark text-white">
                           Assistance: <?php echo $assistance; ?>
                        </p>
                        <div class="card text-center border-dark mb-resp">
                           <div class="card-body">
                              <h3 class="text-secondary">Activities</h3>
                              <p class="text-muted"><?php echo $activities; ?>.</p>
                           </div>
                        </div>
                        <p class="p-2 mt-2 bg-dark text-white">
                           Duration: <?php echo $duration; ?> days
                        </p>
                        <h6 class="text-muted">Date: <?php echo $visiting_date; ?></h6>
                     </div>
                     <div class="card-footer">
                        <a class="btn btn-outline-warning btn-block text-capitalize font-weight-bold" href="booked_slot.php?id=<?php echo $slot_id; ?>"> Book </a>
                     </div>
                  </div>
               </div>
         <?php

            };
         } else {
            echo "0 results";
         }

         ?>

      </div>

   </div>

</section>







<?php include('page_footer.php') ?>;