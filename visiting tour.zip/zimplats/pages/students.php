<?php include('page_header.php')
?>

<?php include('navbar.php'); ?>

<!-- Newsletter -->
<section id="nesletter" class="text-center p-5 bg-dark text-white">
   <div class="container">
      <h1>Students Assistance Platform</h1>
      <div class="row">
         <div class="col-md-5 m-auto text-center">
            <form action="" method="POST" class="form-group justify-content-center">
               <input type="text" name="std_names" class="form-control mb-2 mr-2" placeholder="Enter Name">
               <br>
               <textarea style="width: 100;" name="message" id="" class="form-control mb-2 mr-2" cols="30" rows="5" placeholder="Send your question"></textarea>

               <!-- <input type="email" class="form-control mb-2 mr-2" placeholder="Enter Email"> -->
               <button type="submit" name="send" class="btn btn-primary mb-2">Send</button>
            </form>

            <?php

            if (isset($_POST['send'])) {

               $std_names = $_POST['std_names'];
               $message = $_POST['message'];
               $date = date('d-m-y');
               $comment = "not yet replied";


               $sql = "INSERT INTO students (std_names, message, comment, date)
                VALUES ('{$std_names}','{$message}','{$comment}','{$date}')";

               if ($conn->query($sql) === TRUE) {
                  echo "<p class='alert alert-success text-white text-center p-3'> Message sent</p>";
               } else {
                  echo "Error: " . $sql . "<br>" . $conn->error;
               }
            }


            ?>
         </div>
      </div>
   </div>
</section>



<section class=" bg-light mt-3">
   <div class="container">
      <?php
      $query = "SELECT * FROM students ORDER BY assist_id DESC";
      $select_booked_slot = mysqli_query($conn, $query);

      while ($row = mysqli_fetch_assoc($select_booked_slot)) {

         $assist_id = $row["assist_id"];
         $names = $row["std_names"];
         $msg = $row["message"];
         $dd = $row["date"];
         $comm = $row["comment"];


      ?>


         <h6 class="alert alert-info">

            <strong> <?php echo $names; ?> :-></strong>
            <?php echo $msg; ?>
            <p class="alert alert-success">
               Zimplats:->
               <small>
                  <?php echo $comm ?></small>
            </p>
            <small> Date: <?php echo $dd; ?></small>
         </h6>


      <?php }; ?>
   </div>

</section>














<?php include('page_footer.php') ?>;