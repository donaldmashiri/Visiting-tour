<?php include('page_header.php')
?>

<?php include('navbar.php'); ?>




<section class="bg-light">
   <h4 class="text-center">Book for this Slot</h4>
   <div class="container">
      <h6 class="text-center p-4">
         <?php
         $id = $_GET['id'];
         $query = "SELECT * FROM slots where slot_id = $id";
         $select_booked_slot = mysqli_query($conn, $query);

         while ($row = mysqli_fetch_assoc($select_booked_slot)) {

            $slot_id = $row["slot_id"];
            $assistance = $row["assistance"];
            $activities = $row["activities"];
            $duration = $row["duration"];
            $visiting_date = $row["visiting_date"];


         ?>

            <ul class="list-group list-group-horizontal text-center">
               <li class="list-group-item"> <strong>Assistance: </strong> <?php echo $assistance; ?> </li>
               <li class="list-group-item"> <strong>Activities: </strong> <?php echo $activities; ?> </li>
               <li class="list-group-item"> <strong>Duration: </strong> <?php echo $duration; ?> days </li>
               <li class="list-group-item"> <strong>Visiting Date: </strong> <?php echo $visiting_date; ?> </li>
            </ul>


         <?php  }; ?>
      </h6>

   </div>

   </div>
</section>



<?php

if (isset($_POST['book'])) {
   $full_names = $_POST['full_names'];
   $national_id = $_POST['national_id'];
   $phone = $_POST['phone'];
   $occupation = $_POST['occupation'];

   $status = "pending";


   $sql = "INSERT INTO booked (slot_id, full_names, national_id, phone, occupation, status)
      VALUES ({$slot_id},'{$full_names}', '{$national_id}', '{$phone}','{$occupation}','{$status}')";

   if ($conn->query($sql) === TRUE) {
      echo "<p class='alert alert-success text-dark text-center p-3'>Application was created booked, Check your response after few minutes</p>";
   } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
   }
}


?>


<section id="#" class="mt-3">
   <div class="container">
      <div class="row">
         <div class="col-md-7 m-auto text-center">
            <div class="card">
               <div class="card-header font-weight-bolder">Enter details</div>
               <div class="card-body">
                  <form method="post">
                     <div class="form-group">
                        <label for="title">Fullnames</label>
                        <input type="text" name="full_names" minlength="5" class="form-control" required>
                     </div>
                     <div class="form-group">
                        <label for="title">National ID</label>
                        <input type="text" name="national_id" minlength="5" class="form-control" required>
                     </div>

                     <div class="form-group">
                        <label for="title">Phone Number</label>
                        <input type="text" name="phone" minlength="6" class="form-control" required>
                     </div>

                     <div class="form-group">
                        <label for="title">Occupation</label>
                        <input type="text" name="occupation" minlength="5" class="form-control" required>
                     </div>

                     <button type="submit" class="btn btn-primary" name="book">Submit</button>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>





<?php include('page_footer.php') ?>;