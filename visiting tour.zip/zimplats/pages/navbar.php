<nav class="navbar navbar-expand-sm navbar-dark bg-secondary">
   <div class="container">
      <a href="index.html" class="navbar-brand">
         <img src="../images/zimplatslogo.png" height="40" width="100" alt="Zimplats">
      </a>
      <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
         <sapn class="navbar-toggler-icon"></sapn>
      </button>
      <div class="collapse navbar-collapse" id="navbarCollapse">
         <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
               <a href="../index.php" class="nav-link">Home</a>
            </li>
            <li class="nav-item">
               <a href="applications.php" class="nav-link">Slots Services</a>
            </li>
            <li class="nav-item">
               <a href="track_slot.php" class="nav-link">Authorization Status</a>
            </li>
            <li class="nav-item">
               <a href="students.php" class="nav-link">Students</a>
            </li>
         </ul>
      </div>
   </div>
</nav>