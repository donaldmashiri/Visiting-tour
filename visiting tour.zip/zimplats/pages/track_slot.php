<?php include('page_header.php')
?>

<?php include('navbar.php'); ?>





<div class="container">
   <div class="row text-center">
      <div class="col-md-6">
         <h4>Booked Slots</h4>

         <div class="card">
            <div class="card-header">
               <form action="" method="POST">
                  <div class="form-group">
                     <label for="">Search</label>
                     <input type="text" name="search_booked" placeholder="search" class="form-control" required>
                  </div>
                  <div class="form-group">
                     <button type="submit" name="booked" class="btn btn-secondary">Search</button>
                  </div>
               </form>
            </div>

            <div class="card-body">
               <?php
               if (isset($_POST['booked'])) {

                  $search_booked = $_POST['search_booked'];

                  $query = mysqli_query($conn, "SELECT * FROM booked where national_id = '$search_booked'");
                  $numrows = mysqli_num_rows($query);

                  if ($numrows == 0) {
                     echo "<p class='alert alert-danger'> No matching record of this national ID </p>";
                  } elseif ($numrows >= 1) {
                     $row = mysqli_fetch_array($query);
                     $booked_id = $row["booked_id"];
                     $slot_id = $row["slot_id"];
                     $national_id = $row["national_id"];
                     $full_names = $row["full_names"];
                     $status = $row["status"];


                     echo "<h4>Dear, $full_names</h4>";
                     echo "<p>We are here by advising you that your Application status:</p>";
                     if ($status === "APPROVED") {
                        echo "<p style='color:green'> <strong> $status </strong> </p>";
                        echo "<p>with national ID: <strong> $national_id </strong>  </p>";
                        echo "<p style='color:#E0A800'> SLOT REFERENCE NUMBER: B00$slot_id </p>";
                     } elseif ($status === "DECLINED") {
                        echo "<p style='color:red'> <strong> $status </strong> Sorry try again some other time</p>";
                     } else {
                        echo "<p style='color:#E0A800'> <strong> $status </strong></p>";
                     }
                  }
               }; ?>

            </div>
         </div>


      </div>
      <div class="col-md-6">
         <h4>Specific Applied Slots</h4>
         <div class="card">
            <div class="card-header">
               <form action="" method="POST">
                  <div class="form-group">
                     <label for="">Search</label>
                     <input type="text" name="search_specified" placeholder="search" class="form-control">
                  </div>
                  <div class="form-group">
                     <button type="submit" name="specified_book" class="btn btn-secondary">Search</button>
                  </div>
               </form>
            </div>

            <div class="card-body">
               <?php
               if (isset($_POST['specified_book'])) {

                  $search_specified = $_POST['search_specified'];

                  $query = mysqli_query($conn, "SELECT * FROM applications where national_id = '$search_specified'");
                  $numrows = mysqli_num_rows($query);

                  if ($numrows == 0) {
                     echo "<p class='alert alert-danger'> No matching record of this national ID </p>";
                  } elseif ($numrows >= 1) {
                     $row = mysqli_fetch_array($query);
                     $app_id = $row["application_id"];
                     $full_names = $row["full_names"];
                     $national_id = $row["national_id"];
                     $nature_of_visit = $row["nature_of_visit"];
                     $visiting_date = $row["visiting_date"];
                     $status = $row["status"];


                     echo "<h4>Dear, $full_names</h4>";
                     echo "<p>We are here by advising you that your Application status:</p>";
                     if ($status === "APPROVED") {
                        echo "<p style='color:green'> <strong> $status </strong> </p>";
                        echo "<p>with national ID: <strong> $national_id </strong>  </p>";
                        echo "<p style='color:#E0A800'> SLOT REFERENCE NUMBER: B00$app_id </p>";
                     } elseif ($status === "DECLINED") {
                        echo "<p style='color:red'> <strong> $status </strong> Sorry try again some other time</p>";
                     } else {
                        echo "<p style='color:#E0A800'> <strong> $status </strong></p>";
                     }
                  }
               }; ?>
            </div>



         </div>
      </div>
   </div>













   <?php include('page_footer.php') ?>;