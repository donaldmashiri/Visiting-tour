<?php
include('../includes/header.php');

if (isset($_POST['login'])) {
   $email = $_POST['email'];
   $password = $_POST['password'];

   if (empty($email) or empty($password)) {
      echo "<p class='alert alert-warning text-center mt-3'>Input admin credentials to login</p>";
   } elseif ($email === "admin@gmail.com" && $password === "12345") {
      header('Location: add_slot.php');
   } else {
      echo "<p class='alert alert-danger text-center mt-3'>Ooops Invalid credentials try again......!!!</p>";
   }
}


?>

<section id="#" class="mt-5">
   <div class="container">
      <div class="row">
         <div class="col-md-5 m-auto text-center">
            <div class="card">
               <div class="card-header">Admin Login</div>
               <div class="card-body">
                  <form method="post">
                     <div class="form-group">
                        <label for="a">Email</label>
                        <input type="email" class="form-control" name="email" id="a">
                     </div>

                     <div class="form-group">
                        <label for="p">Password</label>
                        <input type="password" class="form-control" name="password" id="p">
                     </div>

                     <button type="submit" class="btn btn-primary" name="login">Login</button>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>

<?php include('../includes/footer.php'); ?>