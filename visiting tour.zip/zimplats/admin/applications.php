<?php
include('../includes/header.php');
include('adminnav.php');

?>

<div class="container">
   <h4 class="text-center">Applications of Slots</h4>
   <table class="table">
      <thead class="thead-light">
         <tr>
            <th>Ref#</th>
            <th>Fullnames</th>
            <th>National_ID</th>
            <th>Phone</th>
            <th>Occupation</th>
            <th>Nature of Visit</th>
            <th>Visiting Date</th>
            <th>Status</th>
            <th></th>
         </tr>
      </thead>
      <tbody>
         <?php
         $sql = "SELECT * FROM applications ORDER BY application_id DESC";
         $result = $conn->query($sql);

         if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
               $app_id = $row["application_id"];
               $full_names = $row["full_names"];
               $national_id = $row["national_id"];
               $phone = $row["phone"];
               $occupation = $row["occupation"];
               $nature_of_visit = $row["nature_of_visit"];
               $visiting_date = $row["visiting_date"];
               $status = $row["status"];

         ?>
               <tr>
                  <td> SP00<?php echo $app_id; ?> </td>
                  <td><?php echo $full_names; ?> </td>
                  <td><?php echo $national_id; ?> </td>
                  <td><?php echo $phone;  ?> </td>
                  <td><?php echo $occupation;  ?> </td>
                  <td><?php echo $nature_of_visit;  ?>days </td>
                  <td><?php echo $visiting_date; ?> </td>
                  <td>
                     <?php

                     if ($status === "APPROVED") {
                        echo "<p style='color:green'> <strong> $status </strong></p>";
                     } elseif ($status === "DECLINED") {
                        echo "<p style='color:red'> <strong> $status </strong></p>";
                     } else {
                        echo "<p style='color:#E0A800'> <strong> $status </strong></p>";
                     }
                     ?>
                  </td>
                  <td>
                     <form method="post" action="">
                        <a href="applications.php?action=approve&req_id=<?= $app_id ?>" class="btn btn-success btn-block btn-sm">Approve</a>
                        <a href="applications.php?action=decline&req_id=<?= $app_id ?>" class="btn btn-danger  btn-block btn-sm"> Decline </a>
                     </form>
                  </td>
               </tr>

         <?php

            };
         } else {
            echo "0 results";
         }

         ?>



         <?php

         if (isset($_GET['action']) && $_GET['action'] == "approve") {

            $request_id = $_GET['req_id'];
            $approve = "APPROVED";

            $query = "UPDATE applications SET ";
            $query .= "status  = '{$approve}' ";
            $query .= "WHERE application_id = {$request_id} ";

            header("Location: applications.php");

            $update_query = mysqli_query($conn, $query);
            if (!$update_query) {
               die("Query failed" . mysqli_error($conn));
            }
         };

         if (isset($_GET['action']) && $_GET['action'] == "decline") {

            // Declined
            $request_id = $_GET['req_id'];
            $declined = "DECLINED";

            $query = "UPDATE applications SET ";
            $query .= "status  = '{$declined}' ";
            $query .= "WHERE application_id = {$request_id} ";

            header("Location: applications.php");

            $update_query = mysqli_query($conn, $query);
            if (!$update_query) {
               die("Query failed" . mysqli_error($conn));
            }
         };

         ?>










      </tbody>
   </table>
</div>




<?php include('../includes/footer.php'); ?>