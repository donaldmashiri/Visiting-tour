<form method="post" action="">
   <div class="form-group">
      <textarea name="update_comment" id="" class="form-control" minlength="5" cols="5" rows="3"></textarea>
   </div>
   <div class="input-group-btn">
      <button type="submit" name="update" class="btn btn-success">Reply</button>
   </div>
</form>