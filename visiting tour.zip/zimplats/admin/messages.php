<?php
include('../includes/header.php');
include('adminnav.php');


?>


<!-- Posts -->
<section id="posts" class="mt-1">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <div class="card">
               <div class="card-header">
                  <h4>Messages</h4>
               </div>
               <div class="card-body">

                  <section class=" bg-light mt-3">
                     <div class="container">
                        <?php
                        $query = "SELECT * FROM students ORDER BY assist_id DESC";
                        $select_booked_slot = mysqli_query($conn, $query);

                        while ($row = mysqli_fetch_assoc($select_booked_slot)) {

                           $assist_id = $row["assist_id"];
                           $names = $row["std_names"];
                           $msg = $row["message"];
                           $dd = $row["date"];
                           $comm = $row["comment"];


                        ?>


                           <h6 class="alert alert-info">

                              <strong> <?php echo $names; ?> :-></strong>
                              <?php echo $msg; ?>
                              <p class="alert alert-success">
                                 Zimplats:->
                                 <small>
                                    <?php echo $comm ?></small>
                              </p>
                              <small> Date: <?php echo $dd; ?></small>
                              <a href='messages.php?edit=<?= $assist_id ?>'>reply<a />
                           </h6>

                           <?php // UPDATE AND INCLUDE QUERY
                           if (isset($_GET['edit'])) {
                              $cat_id = $_GET['edit'];
                              include "reply.php";
                           }

                           ?>

                           <?php
                           if (isset($_POST['update'])) {

                              $update_comment = $_POST['update_comment'];

                              // echo $update_comment;

                              $query = "UPDATE students SET ";
                              $query .= "comment  = '{$update_comment}' ";
                              $query .= "WHERE assist_id = {$cat_id} ";
                              //
                              $approve_query = mysqli_query($conn, $query);

                              header("Location: messages.php");

                              if (!$approve_query) {
                                 die("Query failed" . mysqli_error($connection));
                              }
                           }
                           ?>


                           <hr>


                        <?php }; ?>


                        <?php

                        if (isset($_GET['action']) && $_GET['action'] == "approve") {

                           $request_id = $_GET['req_id'];
                           $update_comment = $_GET['comm'];

                           echo $update_comment;

                           // $query = "UPDATE students SET ";
                           // $query .= "comment  = '{$update_comment}' ";
                           // $query .= "WHERE assist_id = {$request_id} ";

                           // header("Location: messages.php");

                           // $update_query = mysqli_query($conn, $query);
                           // if (!$update_query) {
                           //    die("Query failed" . mysqli_error($conn));
                           // }
                        };

                        ?>

                     </div>

                  </section>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>


<?php include('../includes/footer.php'); ?>