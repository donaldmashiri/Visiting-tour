<?php
include('../includes/header.php');
include('adminnav.php');

?>

<div class="container">
   <h4 class="text-center">Booked Slots</h4>
   <table class="table">
      <thead class="thead-light">
         <tr>
            <th>#</th>
            <th>Reference#</th>
            <th>Fullnames</th>
            <th>National_ID</th>
            <th>Phone</th>
            <th>Occupation</th>
            <th>Status</th>
            <th></th>
         </tr>
      </thead>
      <tbody>
         <?php
         $sql = "SELECT * FROM booked ORDER BY booked_id DESC";
         $result = $conn->query($sql);

         if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
               $booked_id = $row["booked_id"];
               $slot_id = $row["slot_id"];
               $full_names = $row["full_names"];
               $national_id = $row["national_id"];
               $phone = $row["phone"];
               $occupation = $row["occupation"];
               $status = $row["status"];

         ?>
               <tr>
                  <td> <?php echo $booked_id; ?> </td>
                  <td>B00<?php echo $slot_id; ?> </td>
                  <td><?php echo $full_names; ?> </td>
                  <td><?php echo $national_id; ?> </td>
                  <td><?php echo $phone;  ?> </td>
                  <td><?php echo $occupation;  ?></td>
                  <td>
                     <?php

                     if ($status === "APPROVED") {
                        echo "<p style='color:green'> <strong> $status </strong></p>";
                     } elseif ($status === "DECLINED") {
                        echo "<p style='color:red'> <strong> $status </strong></p>";
                     } else {
                        echo "<p style='color:#E0A800'> <strong> $status </strong></p>";
                     }

                     ?>
                  </td>
                  <td>
                     <form method="post" action="">
                        <a href="booked.php?action=approve&req_id=<?= $booked_id ?>" class="btn btn-success btn-block btn-sm">Approve</a>
                        <a href="booked.php?action=decline&req_id=<?= $booked_id ?>" class="btn btn-danger  btn-block btn-sm"> Decline </a>
                     </form>
                  </td>
               </tr>

         <?php

            };
         } else {
            echo "0 results";
         }

         ?>



         <?php

         if (isset($_GET['action']) && $_GET['action'] == "approve") {

            $request_id = $_GET['req_id'];
            $approve = "APPROVED";

            $query = "UPDATE booked SET ";
            $query .= "status  = '{$approve}' ";
            $query .= "WHERE booked_id = {$request_id} ";

            header("Location: booked.php");

            $update_query = mysqli_query($conn, $query);
            if (!$update_query) {
               die("Query failed" . mysqli_error($conn));
            }
         };

         if (isset($_GET['action']) && $_GET['action'] == "decline") {

            // Declined
            $request_id = $_GET['req_id'];
            $declined = "DECLINED";

            $query = "UPDATE booked SET ";
            $query .= "status  = '{$declined}' ";
            $query .= "WHERE booked_id = {$request_id} ";

            header("Location: booked.php");

            $update_query = mysqli_query($conn, $query);
            if (!$update_query) {
               die("Query failed" . mysqli_error($conn));
            }
         };

         ?>

      </tbody>
   </table>
</div>




<?php include('../includes/footer.php'); ?>