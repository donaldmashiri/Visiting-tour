<?php
include('../includes/header.php');
include('adminnav.php');

if (isset($_POST['add_slot'])) {

   $assistance = $_POST['assistance'];
   $activities = $_POST['activities'];
   $duration = $_POST['duration'];
   $visiting_date = $_POST['visiting_date'];

   $status = false;


   $sql = "INSERT INTO slots (assistance, activities, duration, visiting_date, status)
      VALUES ('{$assistance}', '{$activities}', '{$duration}','{$visiting_date}','{$status}')";

   if ($conn->query($sql) === TRUE) {
      echo "<p class='alert alert-success text-dark text-center p-3'> New slot was created successfully</p>";
   } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
   }
}




?>
<!-- Posts -->
<section id="posts" class="mt-1">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <div class="card">
               <div class="card-header">
                  <h4>Add Slots</h4>
               </div>
               <div class="card-body">
                  <form method="post">
                     <div class="form-group">
                        <label for="a">Assistance</label>
                        <input type="text" class="form-control" minlength="5" name="assistance" required>
                     </div>
                     <div class="form-group">
                        <label for="a">Activities</label>
                        <textarea name="activities" id="" class="form-control" minlength="5" cols="15" rows="5" required></textarea>
                     </div>
                     <div class="form-group">
                        <label for="a">Duration</label>
                        <input type="number" class="form-control" min="1" name="duration" required>
                     </div>
                     <div class="form-group">
                        <label for="p">Date</label>
                        <input type="date" class="form-control" name="visiting_date" required>
                     </div>
                     <button type="submit" class="btn btn-primary btn-block" name="add_slot">submit</button>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>


<?php include('../includes/footer.php'); ?>