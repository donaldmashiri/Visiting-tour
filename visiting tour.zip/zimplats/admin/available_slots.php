<?php
include('../includes/header.php');
include('adminnav.php');

?>
<!-- Posts -->
<section id="posts" class="mt-1">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <div class="card">
               <div class="card-header">
                  <h4>Available Slots</h4>
               </div>
               <table class="table table-striped">
                  <thead class="thead-dark">
                     <tr>
                        <th>Slot#</th>
                        <th>Assistance</th>
                        <th>Activities</th>
                        <th>Duration</th>
                        <th>Visitng Date</th>
                        <th>Status</th>
                        <th></th>
                     </tr>
                  </thead>
                  <tbody>
                     <?php
                     $sql = "SELECT * FROM slots ORDER BY slot_id DESC";
                     $result = $conn->query($sql);

                     if ($result->num_rows > 0) {
                        // output data of each row
                        while ($row = $result->fetch_assoc()) {
                           $slot_id = $row["slot_id"];
                           $assistance = $row["assistance"];
                           $activities = $row["activities"];
                           $duration = $row["duration"];
                           $visiting_date = $row["visiting_date"];
                           $status = $row["status"];

                     ?>
                           <tr>
                              <td> <?php echo $slot_id; ?> </td>
                              <td><?php echo $assistance; ?> </td>
                              <td><?php echo $activities; ?> </td>
                              <td><?php echo $duration;  ?>days </td>
                              <td><?php echo $visiting_date; ?> </td>
                              <td><?php echo $status; ?> </td>
                              <td>
                                 <form method="post" action="">
                                    <a href="available_slots.php?action=approve&req_id=<?= $slot_id ?>" class="btn btn-secondary btn-block btn-sm">Approve</a>
                                    <a href="available_slots.php?action=decline&req_id=<?= $slot_id ?>" class="btn btn-light btn-block btn-sm text-danger">Disable</a>
                                 </form>
                              </td>
                           </tr>

                     <?php

                        };
                     } else {
                        echo "0 results";
                     }

                     ?>


                     <?php

                     if (isset($_GET['action']) && $_GET['action'] == "approve") {

                        $request_id = $_GET['req_id'];
                        $able = true;

                        $query = "UPDATE slots SET ";
                        $query .= "status  = '{$able}' ";
                        $query .= "WHERE slot_id = {$request_id} ";

                        header("Location: available_slots.php");

                        $update_query = mysqli_query($conn, $query);
                        if (!$update_query) {
                           die("Query failed" . mysqli_error($conn));
                        }
                     };

                     if (isset($_GET['action']) && $_GET['action'] == "decline") {

                        // Declined
                        $request_id = $_GET['req_id'];
                        $declined = false;

                        $query = "UPDATE slots SET ";
                        $query .= "status  = '{$declined}' ";
                        $query .= "WHERE slot_id = {$request_id} ";

                        header("Location: available_slots.php");

                        $update_query = mysqli_query($conn, $query);
                        if (!$update_query) {
                           die("Query failed" . mysqli_error($conn));
                        }
                     };



                     ?>








                  </tbody>
               </table>
            </div>
         </div>

      </div>
   </div>
</section>


<?php include('../includes/footer.php'); ?>