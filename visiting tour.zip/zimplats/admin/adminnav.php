 <section id="#" class="py-4 bg-light">
    <div class="container">
       <div class="row">
          <div class="col-md-2">
             <a href="add_slot.php" class="btn btn-primary btn-block">Add slot</a>
          </div>
          <div class="col-md-2">
             <a href="available_slots.php" class="btn btn-warning btn-block">Available Slots</a>
          </div>
          <div class="col-md-2">
             <a href="applications.php" class="btn btn-success btn-block">Applications</a>
          </div>
          <div class="col-md-2">
             <a href="booked.php" class="btn btn-secondary btn-block">Booked Slots</a>
          </div>
          <div class="col-md-2">
             <a href="messages.php" class="btn btn-dark btn-block">Messages</a>
          </div>
          <div class="col-md-2">
             <a href="reports.php" class="btn btn-danger btn-block">Reports</a>
          </div>
       </div>
    </div>
 </section>