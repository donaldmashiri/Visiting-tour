<?php
include('../includes/header.php');
include('adminnav.php');

?>

<section id="posts" class="mt-1">
   <div class="container">
      <div class="row">
         <div class="col-md-12">

            <h4 class="text-center">Applications of Slots</h4>
            <table class="table table-bordered">
               <thead>
                  <tr>
                     <th>Ref#</th>
                     <th>Fullnames</th>
                     <th>National_ID</th>
                     <th>Phone</th>
                     <th>Occupation</th>
                     <th>Nature of Visit</th>
                     <th>Visiting Date</th>
                     <th>Status</th>
                  </tr>
               </thead>
               <tbody>
                  <?php
                  $sql = "SELECT * FROM applications ORDER BY application_id DESC LIMIT 5";
                  $result = $conn->query($sql);

                  if ($result->num_rows > 0) {
                     while ($row = $result->fetch_assoc()) {
                        $app_id = $row["application_id"];
                        $full_names = $row["full_names"];
                        $national_id = $row["national_id"];
                        $phone = $row["phone"];
                        $occupation = $row["occupation"];
                        $nature_of_visit = $row["nature_of_visit"];
                        $visiting_date = $row["visiting_date"];
                        $status = $row["status"];

                  ?>
                        <tr>
                           <td> SP00<?php echo $app_id; ?> </td>
                           <td><?php echo $full_names; ?> </td>
                           <td><?php echo $national_id; ?> </td>
                           <td><?php echo $phone;  ?> </td>
                           <td><?php echo $occupation;  ?> </td>
                           <td><?php echo $nature_of_visit;  ?>days </td>
                           <td><?php echo $visiting_date; ?> </td>
                           <td><?php echo $status; ?> </td>
                        </tr>

                  <?php

                     };
                  } else {
                     echo "0 results";
                  }

                  ?>
               </tbody>
            </table>
         </div>
      </div>
   </div>
</section>

<hr>


<section id="posts" class="mt-1">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <h4 class="text-center">Booked Slots</h4>
            <table class="table table-bordered">
               <thead>
                  <tr>
                     <th>#</th>
                     <th>Reference#</th>
                     <th>Fullnames</th>
                     <th>National_ID</th>
                     <th>Phone</th>
                     <th>Occupation</th>
                     <th>Status</th>
                  </tr>
               </thead>
               <tbody>
                  <?php
                  $sql = "SELECT * FROM booked ORDER BY booked_id DESC LIMIT 5";
                  $result = $conn->query($sql);

                  if ($result->num_rows > 0) {
                     // output data of each row
                     while ($row = $result->fetch_assoc()) {
                        $booked_id = $row["booked_id"];
                        $slot_id = $row["slot_id"];
                        $full_names = $row["full_names"];
                        $national_id = $row["national_id"];
                        $phone = $row["phone"];
                        $occupation = $row["occupation"];
                        $status = $row["status"];

                  ?>
                        <tr>
                           <td> <?php echo $booked_id; ?> </td>
                           <td>B00<?php echo $slot_id; ?> </td>
                           <td><?php echo $full_names; ?> </td>
                           <td><?php echo $national_id; ?> </td>
                           <td><?php echo $phone;  ?> </td>
                           <td><?php echo $occupation;  ?></td>
                           <td><?php echo $status;  ?></td>
                        </tr>

                  <?php

                     };
                  } else {
                     echo "0 results";
                  }
                  ?>

               </tbody>
            </table>

         </div>
      </div>
   </div>
</section>










<hr>





<?php include('../includes/footer.php'); ?>