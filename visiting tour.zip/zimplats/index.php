<?php include('includes/db.php') ?>

<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Zimplats</title>
   <link rel="stylesheet" href="css/bootstrap.min.css">
   <script src="https://kit.fontawesome.com/926d2e4bfd.js" crossorigin="anonymous"></script>
</head>

<body>

   <nav class="navbar navbar-expand-sm navbar-dark bg-secondary">
      <div class="container">
         <a href="index.html" class="navbar-brand">
            <img src="images/zimplatslogo.png" height="40" width="100" alt="Zimplats">
         </a>
         <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
            <sapn class="navbar-toggler-icon"></sapn>
         </button>
         <div class="collapse navbar-collapse" id="navbarCollapse">
            <ul class="navbar-nav ml-auto">
               <li class="nav-item active">
                  <a href="index.php" class="nav-link">Home</a>
               </li>
               <li class="nav-item">
                  <a href="pages/applications.php" class="nav-link">Slots Services</a>
               </li>
               <li class="nav-item">
                  <a href="pages/track_slot.php" class="nav-link">Authorization Status</a>
               </li>
               <li class="nav-item">
                  <a href="pages/students.php" class="nav-link">Students</a>
               </li>
            </ul>
         </div>
      </div>
   </nav>

   <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
      <ol class="carousel-indicators">
         <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
         <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
         <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
      </ol>
      <div class="carousel-inner">
         <div class="carousel-item active">
            <img src="images/Zimplats1.jpg" class="d-block w-100" height="500" alt="...">
         </div>
         <div class="carousel-item">
            <img src="images/Zimplats2.jpg" class="d-block w-100" height="500" alt="...">
         </div>
         <div class="carousel-item">
            <img src="images/Zimplats3.jpg" class="d-block w-100" height="500" alt="...">
         </div>
      </div>
      <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
         <span class="carousel-control-prev-icon" aria-hidden="true"></span>
         <span class="sr-only">Previous</span>
      </a>
      <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
         <span class="carousel-control-next-icon" aria-hidden="true"></span>
         <span class="sr-only">Next</span>
      </a>
   </div>


   <!-- Info Section -->
   <!-- <section id="info" class="py-3 bg-dark text-white">
      <div class="container">
         <div class="row">
            <div class="text-center">
               <h3>Welcome to Zimplats Visiting Tour</h3>
               <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Placeat expedita sunt quis voluptate itaque
                  nobis perferendis totam laudantium laborum qui.</p>
            </div>

            <div class="col-md-6 align-self-center">
               <video width="520" height="440" controls>
                  <source src="images/zimplats.mp4" type="video/mp4">
                  <source src="images/zimplats.ogg" type="video/ogg">
                  Your browser does not support the video tag.
               </video>
            </div>
            <div class="col-md-6 text-center">
               <img src="images/zimplatslogo.png" height="300" width="300" alt="Zimplats">
            </div>
         </div>
      </div>
   </section> -->


   <!-- Available slots -->
   <section class="bg-light text-white">
      <div class="container">
         <br>
         <h4 class="text-info text-center text-capitalize font-weight-bold">Hurry book for Available slot</h4>
         <a href="pages/applications.php" class="btn btn-outline-secondary text-center">View all</a>
         <div class="row text-center">
            <?php
            $ss = true;
            $sql = "SELECT * FROM slots WHERE status = $ss LIMIT 3";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
               // output data of each row
               while ($row = $result->fetch_assoc()) {
                  $slot_id = $row["slot_id"];
                  $assistance = $row["assistance"];
                  $activities = $row["activities"];
                  $duration = $row["duration"];
                  $visiting_date = $row["visiting_date"];


            ?>
                  <div class="col-md-4">
                     <div class="card mt-2">
                        <div class="card-header text-dark text-capitalize font-weight-bolder">Slot details</div>
                        <div class="card-body">
                           <p class="p-2 mb-3 bg-dark text-white">
                              Assistance: <?php echo $assistance; ?>
                           </p>
                           <div class="card text-center border-dark mb-resp">
                              <div class="card-body">
                                 <h3 class="text-secondary">Activities</h3>
                                 <p class="text-muted"><?php echo $activities; ?>.</p>
                              </div>
                           </div>
                           <p class="p-2 mt-2 bg-dark text-white">
                              Duration: <?php echo $duration; ?> days
                           </p>
                           <h6 class="text-muted">Date: <?php echo $visiting_date; ?></h6>
                        </div>
                        <div class="card-footer">
                           <a class="btn btn-outline-warning btn-block text-capitalize font-weight-bold" href="pages/booked_slot.php?id=<?php echo $slot_id; ?>"> Book </a>
                        </div>
                     </div>
                  </div>
            <?php

               };
            } else {
               echo "0 results";
            }

            ?>

         </div>

      </div>
   </section>


   <!-- About / Why Section -->
   <section id="about" class="py-5 text-center bg-light">
      <div class="container">
         <div class="row">
            <div class="col">
               <div class="info-header mb-5">
                  <h1 class="text-info pb-3">
                     Public Information
                  </h1>
               </div>

               <!-- Accordion -->
               <div id="accordion">
                  <div class="card">
                     <div class="card-header">
                        <h5 class="mb-0">
                           <div href="#collapse1" data-toggle="collapse" data-parent="#accordion">
                              <i class="fa fa-arrow-circle-down"></i>Zimplats Story
                           </div>
                        </h5>
                     </div>

                     <div id="collapse1" class="collapse show">
                        <div class="card-body">
                           From the deepest quarry to the international trading rooms, we search and offer to the world a piece of Zimbabwe’s heart. Our business is focused on the extraction and marketing of platinum and platnimun group of metals. But this is not our cause. We are inspired by a Great Zimbabwean civilisation that constructed monolithic structures in the ancient of days which still stand today in Masvingo.
                           From our ancestors, this story continues and we are playing our part by using our natural resources to build the greatest Zimbabwe yet.
                           The Zimplats story is the Zimbabwean story.
                        </div>
                     </div>


                  </div>

                  <div class="card">
                     <div class="card-header">
                        <h5 class="mb-0">
                           <div href="#collapse2" data-toggle="collapse" data-parent="#accordion">
                              <i class="fa fa-arrow-circle-down"></i> Our Focus
                           </div>
                        </h5>
                     </div>

                     <div id="collapse2" class="collapse">
                        <div class="card-body">
                           Zimplats’ business is production of platinum group and associated metals from the Great Dyke in Zimbabwe. Our vision is to be the safety and cost leader in the platinum sector with sustainable growth in production, whilst generating superior returns, for the benefit of all our stakeholders.
                           We will achieve our mission and vision through purposeful and focused attention to the:
                           Extraction of mineral resources in a socially and environmentally friendly manner
                        </div>
                     </div>
                  </div>
               </div>


            </div>
         </div>
      </div>
   </section>





   <footer id="main-footer" class="bg-light text-dark text-capitalize font-weight-bold mt-5 p-2">
      <div class="container">
         <div class="row">
            <div class="col">
               <p class="lead text-center">
                  Copyright &copy;
                  <span id="year"></span>
                  ZimPlats
               </p>
            </div>
         </div>
      </div>
   </footer>


   <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
   <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>


</body>

</html>